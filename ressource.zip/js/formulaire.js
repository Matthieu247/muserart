// Sélectionner les éléments
const form = document.getElementById('loginForm');
const emailInput = form.querySelector('input[name="email"]');
const motDePasseInput = form.querySelector('#motdepasse');
const nomInput = form.querySelector('#nom');
const prenomInput = form.querySelector('#prenom');

const messageEmail = document.getElementById('messageEmail');
const messagePassword = document.getElementById('messagePassword');

// Message de base du mot de passe
messagePassword.textContent = "Le mot de passe doit contenir au moins 3 caractères, une majuscule, une minuscule et un chiffre.";

// Fonction de validation de l'email
function valideEmail() {
    const emailValue = emailInput.value;
    const regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (regex.test(emailValue)) {
        messageEmail.textContent = "L'email est valide.";
        messageEmail.style.color = 'green';
        return true;
    } else {
        messageEmail.textContent = "L'email est invalide.";
        messageEmail.style.color = 'red';
        return false;
    }
}

// Fonction de validation du mot de passe
function validePassword() {
    const motDePasseValue = motDePasseInput.value;
    const regex2 = /^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9]).{3,}$/;

    if (regex2.test(motDePasseValue)) {
        messagePassword.textContent = "Le mot de passe est fort.";
        messagePassword.style.color = "green";
        return true;
    } else {
        messagePassword.textContent = "Le mot de passe doit contenir au moins 3 caractères, une majuscule, une minuscule et un chiffre.";
        messagePassword.style.color = "red";
        return false;
    }
}

// Vérifie si le champ n'est pas vide
function valideChampTexte(champ) {
    return champ.value.trim() !== "";
}

// Ajouter les écouteurs pour mise à jour en temps réel
emailInput.addEventListener('input', valideEmail);
motDePasseInput.addEventListener('input', validePassword);

// Empêcher l'envoi du formulaire si un champ est invalide
form.addEventListener('submit', function (event) {
    const emailValide = valideEmail();
    const motDePasseValide = validePassword();
    const nomValide = valideChampTexte(nomInput);
    const prenomValide = valideChampTexte(prenomInput);

    if (!nomValide || !prenomValide || !emailValide || !motDePasseValide) {
        event.preventDefault();
        alert("Veuillez remplir correctement tous les champs avant de soumettre.");
    } else {
        form.submit();
    }
});
