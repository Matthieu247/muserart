let slideIndex = 0; // Variable pour suivre l'index de l'image actuelle
function showSlides() {
    let slides = document.getElementsByClassName("slides"); // Récupère toutes les images du diaporama
   
    // Cache toutes les images
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    // Passe à l'image suivante
    slideIndex++;

    // Revient à la première image après la dernière
    if (slideIndex > slides.length) { slideIndex = 1; }
    slides[slideIndex - 1].style.display = "block";
    
    // Affiche l'image actuelle
    setTimeout(showSlides, 3000);
}
// Lance le diaporama
showSlides();